package com.musicPlayer.service;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;
 
/* Author: Mannu Kumar Pandey
 * Email: mannupandeyskit001@gmail.com
 * MobileNumber: 9902438675
 * Experience : 2 Years
 * Technical Skills: Core JAVA,Advance JAVA, J2EE, Hibernate, Spring,JSP, JAVAScript
*/



/*File MyFinalAudioPlayer.java contains:
First Approach to develop the required Music Player with 
Services of PLAY, PLAY Previous and PLAY Next.*/ 



/*File MusicPlayerUsingClips.java contains
Second Approach to develop the required Music Player with 
Services of PLAY, PAUSE, RESUME,RESTART and STOP.*/







public class MyFinalAudioPlayer {

 
    // size of the byte buffer used to read/write the audio stream
    private static final int BUFFER_SIZE = 4096;
    File baseFolderOfSongs= new File("D:/Downloads/Songs/WAV");
    String listOfAllSongs[]=baseFolderOfSongs.list();
    String vv[]= RandomizeStringArray(listOfAllSongs);
    
    ArrayList<String> arrayListObjectForAllSongs=new ArrayList<String>();
    ArrayList<String> arrayListObjectInNextClick=new ArrayList<String>();
    ArrayList<String> arrayListObjectInPreviousClick=new ArrayList<String>();
    
    SourceDataLine audioLine;
    AudioInputStream audioStream;
    AudioFormat format;
    String currentSong;
    
    int indexOfCurrentSong=0;
    
/*This method is used for playing all the songs in a random order. It accepts all the audio file names as input.
    Once all the audio files will be played successfully, The system will be stopped automatically. This method will play all the songs
    
     */
    void play(ArrayList<String> vv,int indexOfCurrentSong) {    
    	for(int x=indexOfCurrentSong; x<=vv.size()-1;x++ ){    		
    	
        	File audioFile = new File("D:/Downloads/Songs/WAV/"+vv.get(x));
    		
        try {
             audioStream = AudioSystem.getAudioInputStream(audioFile);
             format = audioStream.getFormat();
            DataLine.Info info = new DataLine.Info(SourceDataLine.class, format);
            audioLine = (SourceDataLine) AudioSystem.getLine(info);          
            audioLine.open(format);
            audioLine.start();    
            System.out.println("Music playback started:::"+vv.get(x) );
                       
            byte[] bytesBuffer = new byte[BUFFER_SIZE];
            int bytesRead = -1;
            while ((bytesRead = audioStream.read(bytesBuffer)) != -1) {
                audioLine.write(bytesBuffer, 0, bytesRead);
            }             
            audioLine.drain();
            audioLine.close();
            audioStream.close();            
            System.out.println("Music playback completed:::"+vv.get(x));
           
        } catch (UnsupportedAudioFileException ex) {
            System.out.println("The specified audio file is not supported.");
            ex.printStackTrace();
        } catch (LineUnavailableException ex) {
            System.out.println("Audio line for playing back is unavailable.");
            ex.printStackTrace();
        } catch (IOException ex) {
            System.out.println("Error playing the audio file.");
            ex.printStackTrace();
        }    catch (Exception ex) {
            ex.printStackTrace();
        }      
    }
  }

	public static void main(String[] args) {
		try {
			Scanner sc = new Scanner(System.in);
			while (true) {
				System.out.println("Press:- 1 To start playing all the songs in random order.");
				System.out.println("Press:- 2 To play the PREVIOUS song.");
				System.out.println("Press:- 3 To play the NEXT song.");
				int c = sc.nextInt();
				new MyFinalAudioPlayer().gotoChoice(c);
				if (c == 4)
					break;
			}
			sc.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	 void gotoChoice(int c) throws IOException, LineUnavailableException, UnsupportedAudioFileException  
	    { 
		switch (c) {
		/*Case 1 is used for playing all the songs of base folder*/ 
		case 1: for(String currentString:vv ){arrayListObjectForAllSongs.add(currentString);}
			new MyFinalAudioPlayer().play(arrayListObjectForAllSongs,indexOfCurrentSong);
			break;
			
			
		case 2: /*Case 2 is used for playing all the songs of base folder including current and its previous song*/
			if(indexOfCurrentSong!=0){
				indexOfCurrentSong=indexOfCurrentSong-1;
			}
			new MyFinalAudioPlayer().play(arrayListObjectForAllSongs,indexOfCurrentSong);
			break;
		case 3:/*Case 3 is used for playing all the songs of base folder after current song(Execluding song)*/ 
			if(indexOfCurrentSong<=arrayListObjectForAllSongs.size()-1){ 
			indexOfCurrentSong=indexOfCurrentSong+1;
		}
			new MyFinalAudioPlayer().play(arrayListObjectForAllSongs,indexOfCurrentSong);
			break;
		
	        } 
	      
	    } 
	 
//Used for random selection of songs from the base folder.
    public static String [] RandomizeStringArray(String[] array){
    	Random rgen = new Random();  // Random number generator			
    	for (int i=0; i<array.length; i++) {
    	    int randomPosition = rgen.nextInt(array.length);
    	    String temp = array[i];
    	    array[i] = array[randomPosition];
    	    array[randomPosition] = temp;
    	}
    	return array;
    }
 
 
}